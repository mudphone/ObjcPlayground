/*   FSNSFont.h Copyright (c) 2004-2009 Philippe Mougin.  */
/*   This software is open source. See the license.   */  

#import <AppKit/AppKit.h>


@interface NSFont (FSNSFont)

-(void)inspect;

@end
