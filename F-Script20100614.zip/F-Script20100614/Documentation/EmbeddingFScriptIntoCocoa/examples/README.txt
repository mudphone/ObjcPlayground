

The projects in this package assume that FScript.framework is installed in /Library/Frameworks/

Note that these examples are designed for use in automatic garbage collection mode. If you use them in reference counting mode, you should add required retain/release/autorelease calls.
