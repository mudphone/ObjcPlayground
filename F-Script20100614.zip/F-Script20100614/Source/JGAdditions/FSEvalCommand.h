//  FSEvalScriptCommand.h Copyright (c) 2002 Joerg Garbers.
//  This software is open source. See the license.

#import <Foundation/Foundation.h>


@interface FSEvalCommand : NSScriptCommand {

}
- (id)performDefaultImplementation;

@end
