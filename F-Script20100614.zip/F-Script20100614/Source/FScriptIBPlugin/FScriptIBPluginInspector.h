/*   FScriptIBPluginInspector.h Copyright (c) 2007-2009 Philippe Mougin.  */
/*   This software is open source. See the license.  */  

#import <InterfaceBuilderKit/InterfaceBuilderKit.h>

@interface FScriptIBPluginInspector : IBInspector {

}
@end
