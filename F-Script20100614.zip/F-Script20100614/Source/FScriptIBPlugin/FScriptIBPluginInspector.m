/*   FScriptIBPluginInspector.m Copyright (c) 2007-2009 Philippe Mougin.  */
/*   This software is open source. See the license.  */  

#import "FScriptIBPluginInspector.h"

@implementation FScriptIBPluginInspector

- (NSString *)viewNibName {
	return @"FScriptIBPluginInspector";
}

- (void)refresh {
	// Synchronize your inspector's content view with the currently
	// selected objects
}

@end
