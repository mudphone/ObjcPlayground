/*   DOCustom.h Copyright (c) 1998-2009 Philippe Mougin.  */
/*   This software is open source. See the license.       */

#import <Foundation/Foundation.h>


@interface DOCustom : NSObject 
{
  NSInteger i;
}

- (NSInteger) getValue;

@end
