/* FSInterpreterViewPrivate.h Copyright (c) 2004-2009 Philippe Mougin.  */
/*   This software is open source. See the license.  */  

#import "FSInterpreterView.h"

@interface FSInterpreterView (FSInterpreterViewPrivate)

-(void) setInterpreter:(FSInterpreter *)theInterpreter;

@end
