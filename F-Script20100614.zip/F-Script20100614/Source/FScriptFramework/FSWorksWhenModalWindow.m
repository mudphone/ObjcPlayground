/*   FSWorksWhenModalWindow.m Copyright (c) 2009 Philippe Mougin.  */
/*   This software is open source. See the license.  */  

#import "FSWorksWhenModalWindow.h"


@implementation FSWorksWhenModalWindow

- (BOOL) worksWhenModal;
{
  return YES;
}

@end
