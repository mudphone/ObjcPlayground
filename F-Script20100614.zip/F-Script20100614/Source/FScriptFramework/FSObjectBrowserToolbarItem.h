/*   FSObjectBrowserToolbarItem.h Copyright (c) 2002-2009 Philippe Mougin.  */
/*   This software is open source. See the license.               */

#import <Cocoa/Cocoa.h>

@interface FSObjectBrowserToolbarItem : NSToolbarItem 
{}
@end
