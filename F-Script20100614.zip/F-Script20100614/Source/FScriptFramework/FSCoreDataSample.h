/* FSCoreDataSample.h Copyright (c) 2005-2009 Philippe Mougin.  */
/*   This software is open source. See the licence.  */  

#import <Cocoa/Cocoa.h>


@interface FSCoreDataSample : NSObject {

}

+ managedObject;

@end
