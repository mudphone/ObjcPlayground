/*   FSNSFileHandle.h Copyright (c) 2009 Philippe Mougin.  */
/*   This software is open source. See the license.        */  

#import <Cocoa/Cocoa.h>


@interface NSFileHandle (FSNSFileHandle)

- (void) print:(NSString *)string;

@end
