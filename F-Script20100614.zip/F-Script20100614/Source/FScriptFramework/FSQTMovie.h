/*   FSQTMovie.h Copyright (c) 2005-2009 Philippe Mougin.  */
/*   This software is open source. See the license.   */  

#import <QTKit/QTKit.h>


@interface QTMovie (FSQTMovie)

-(void)inspect;

@end
