/* FSVoidPrivate.h created by Philippe Mougin on Mon 15-May-2000 */
/* FSVoidPrivate.h Copyright (c) 2000 Philippe Mougin.   */
/* This software is open source. See the license.  */  

#import "FSVoid.h"

extern FSVoid *fsVoid;
