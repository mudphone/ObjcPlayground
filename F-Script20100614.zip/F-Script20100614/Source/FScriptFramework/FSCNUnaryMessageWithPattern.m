/*   FSCNUnaryMessageWithPattern.m Copyright (c) 2008 Philippe Mougin. */
/*   This software is open source. See the license.   */

#import "FSCNUnaryMessageWithPattern.h"

@implementation FSCNUnaryMessageWithPattern

@end
