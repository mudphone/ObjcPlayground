/*   FSCNUnaryMessageWithPattern.h Copyright (c) 2008 Philippe Mougin. */
/*   This software is open source. See the license.   */

#import "FSCNUnaryMessage.h"

@interface FSCNUnaryMessageWithPattern : FSCNUnaryMessage
{
@public
  FSPattern *pattern;
}

@end
