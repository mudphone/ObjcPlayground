/*   build_config.h Copyright (c) 1999 Philippe Mougin.    */
/*   This software is open source. See the license.    */  

/* Some parameters in order to control the build process of the F-Script framework itself */


// In order to force the interpreter to always use NSInvocation when sending
// a F-Script message to an object.
//#define MESSAGING_USES_NSINVOCATION
  
