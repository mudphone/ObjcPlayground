/*   FSConstantsInitialization.h Copyright (c) 1999-2009 Philippe Mougin.  */
/*   This software is open source. See the license.  */  

#import <Foundation/Foundation.h>

extern void FSConstantsInitialization(NSMutableDictionary *constant_dict);
 

