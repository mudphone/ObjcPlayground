/*   ConstantsDictionaryGenerator.h Copyright (c) 2003-2009 Philippe Mougin.  */
/*   This software is open source. See the license.     */   

#import <Foundation/Foundation.h>


@interface FSConstantsDictionaryGenerator : NSObject {

}

@end
