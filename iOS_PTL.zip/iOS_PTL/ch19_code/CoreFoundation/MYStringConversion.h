//
//  MYStringConversion.h
//  Chapter17
//

char * MYCFStringCopyUTF8String(CFStringRef aString);
const char * MYCFStringGetUTF8String(CFStringRef aString, char **buffer);
