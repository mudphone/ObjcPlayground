//
//  UIAlertViewWithBlocksAppDelegate.h
//  UIAlertViewWithBlocks
//

#import <UIKit/UIKit.h>

@interface UIAlertViewWithBlocksAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, strong) IBOutlet UIWindow *window;

@end
