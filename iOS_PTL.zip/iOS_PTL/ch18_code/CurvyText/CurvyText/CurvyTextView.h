//
//  CurvyTextView.h
//  CurvyText
//
//  Created by Rob Napier on 8/28/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CurvyTextView : UIView
@property (nonatomic, copy) NSAttributedString *attributedString;
@end
