//
//  main.m
//  FileExplorer
//
//  Created by Rob Napier on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "FileExplorerAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([FileExplorerAppDelegate class]));
  }
}
