//
//  CPAppDelegate.m
//  CryptPic
//

#import "CPAppDelegate.h"

@implementation CPAppDelegate

@synthesize window = _window;


@end
