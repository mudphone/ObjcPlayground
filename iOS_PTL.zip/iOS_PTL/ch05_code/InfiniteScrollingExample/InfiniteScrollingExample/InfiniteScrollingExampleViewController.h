//
//  PullToRefreshTableViewExampleViewController.h
//  PullToRefreshTableViewExample
//
//  Created by Mugunth Kumar M on 23/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PullToRefreshViewController.h"

@interface InfiniteScrollingExampleViewController : PullToRefreshViewController

@property int pageCount;
@end
