//
//  InlineEditingExampleViewController.h
//  InlineEditingExample
//
//  Created by Mugunth Kumar M on 30/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InlineEditingExampleViewController : UITableViewController <UITextFieldDelegate>

@property (nonatomic, strong) NSMutableArray *data;
@end
