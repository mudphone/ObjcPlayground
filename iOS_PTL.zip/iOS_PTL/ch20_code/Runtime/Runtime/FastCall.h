//
//  FastCall.h
//  Runtime
//
//  Created by Rob Napier on 8/22/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <objc/runtime.h>

void FastCall(void);
