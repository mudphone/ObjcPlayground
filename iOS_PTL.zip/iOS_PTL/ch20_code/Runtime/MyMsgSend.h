//
//  MyMsgSend.h
//  Runtime
//
//  Created by Rob Napier on 8/22/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef Runtime_MyMsgSend_h
#define Runtime_MyMsgSend_h

void RunMyMsgSend(void);

#endif
