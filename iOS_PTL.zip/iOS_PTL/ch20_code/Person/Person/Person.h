//
//  Person.h
//  Person
//
//  Created by Rob Napier on 8/22/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
@property (copy) NSString *givenName;
@property (copy) NSString *surname;
@end
