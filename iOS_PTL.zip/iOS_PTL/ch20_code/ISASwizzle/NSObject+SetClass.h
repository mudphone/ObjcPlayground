//
//  NSObject+SetClass.h
//  ISASwizzle
//
//  Created by Rob Napier on 6/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (SetClass)
- (void)setClass:(Class)aClass;
@end
