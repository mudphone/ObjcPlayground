//
//  MenuItemsViewController.h
//  iHotelApp
//

#import <UIKit/UIKit.h>


@interface MenuItemsViewController : UITableViewController {
    
}

@property (nonatomic, strong) NSMutableArray *menuItems;
@end
