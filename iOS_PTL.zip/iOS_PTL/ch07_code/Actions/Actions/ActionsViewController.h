//
//  ActionsViewController.h
//  Actions
//
//  Created by Rob Napier on 7/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActionsViewController : UIViewController

@end
