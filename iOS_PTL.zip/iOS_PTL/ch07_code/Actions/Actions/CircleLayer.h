//
//  CircleLayer.h
//  Actions
//
//  Created by Rob Napier on 7/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface CircleLayer : CALayer
@property (nonatomic, readwrite, assign) CGFloat radius;
@end
