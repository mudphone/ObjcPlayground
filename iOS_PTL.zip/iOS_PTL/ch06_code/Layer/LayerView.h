//
//  LayerView.h
//  Layer
//
//  Created by Rob Napier on 7/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LayerView : UIView
@end
