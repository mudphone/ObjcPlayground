//
//  main.m
//  ErrorRecovery
//
//  Created by Rob Napier on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ErrorRecoveryAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([ErrorRecoveryAppDelegate class]));
  }
}
