#include <objc/objc.h>

@interface Super { id isa; } 
+class;
+(int)classMethod;
-(int)instanceMethod;
@end
