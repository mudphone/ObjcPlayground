@interface GC @end
@implementation GC @end

// silence "no debug symbols in executable" warning
void foo(void) { }
